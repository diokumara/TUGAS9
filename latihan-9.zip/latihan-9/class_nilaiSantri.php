<?php 
    class NilaiSantri{
        public $nama;
        public $nilai;
        public $sekolah = 'PeTIK';

        public function getHasil(){
            if($this->nilai > 70) return '<i>LULUS</i>';
            else return 'TIDAK <i>LULUS</i>';
        }
    }

?>