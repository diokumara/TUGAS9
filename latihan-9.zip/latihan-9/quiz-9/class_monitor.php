<?php 
class monitor{
    // properties atau variable
    public $name;
    public $asal;

    function set_name($name){
        $this->name = $name;
    }

    function set_asal($asal){
        $this->asal = $asal;
    }

    function get_name(){
        return $this->name;
    }

    function get_asal(){
        return $this->asal;
    }
}
?>