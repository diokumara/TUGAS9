<?php 
    // tangkap request class_fruit
    require_once 'class_monitor.php';

    // create instan objek fruit : $apple and $banana
    $hp = new monitor();
    $samsung = new monitor();
    $xiaomi = new monitor();
    $lg = new monitor();
    $aoc = new monitor();

    // call member class
    $hp->set_name('HP');
    $hp->set_asal('Amerika');
    $samsung->set_name('Samsung');
    $samsung->set_asal('Korea');
    $xiaomi->set_name('Xiaomi');
    $xiaomi->set_asal('Tiongkok');
    $lg->set_name('LG');
    $lg->set_asal('Korea Selatan');
    $aoc->set_name('AOC');
    $aoc->set_asal('Taiwan');

    echo 'Brand Monitor '.$hp->get_name().' Asalnya '.$hp->get_asal();
    echo '<br/><br/>Brand Monitor '.$samsung->get_name().' Asalnya '.$samsung->get_asal();
    echo '<br/><br/>Brand Monitor '.$xiaomi->get_name().' Asalnya '.$xiaomi->get_asal();
    echo '<br/><br/>Brand Monitor '.$lg->get_name().' Asalnya '.$lg->get_asal();
    echo '<br/><br/>Brand Monitor '.$aoc->get_name().' Asalnya '.$aoc->get_asal();
?>